# CRUD Vendas — Programação Web 2

**Acadêmica:** Izlaine Wilhelm  
**Disciplina:** Programação Web 2  
**Professor:** Danilo Souza Almeida

## Sobre o projeto
Aplicação web para gerenciamento de catálogo de vendas, implementando CRUD de **Marcas**, **Categorias** e **Produtos**, com hierarquia de categorias e upload de imagens.

## Tecnologias
- Java 17
- Jakarta Faces (JSF)
- PrimeFaces
- JPA / Hibernate
- PostgreSQL
- Maven
- Git / GitHub

## Estrutura
- `model`: entidades JPA e validações
- `dao`: persistência com EntityManager
- `controller`: Managed Beans CDI
- `converter`: conversores para menus JSF
- `sql`: DDL e carga inicial
- `src/main/webapp`: páginas XHTML e recursos

## Requisitos atendidos
- CRUD de Marca com nome único e exclusão.
- CRUD de Categoria com auto-relacionamento e caminho hierárquico.
- CRUD de Produto relacionando Marca e Categoria.
- Upload de JPG, PNG e WEBP.
- DataTables com paginação e filtros.
- Mensagens PrimeFaces e confirmações de exclusão.
- `.gitignore` para arquivos de IDE e `target`.

## Como executar
1. Instale JDK 17, Maven, PostgreSQL e um servidor Jakarta EE 10, como WildFly.
2. Crie o banco `vendas` e execute `sql/01_schema.sql` e `sql/02_seed.sql`.
3. Confira usuário e senha do PostgreSQL em `src/main/resources/META-INF/persistence.xml`.
4. Execute `mvn clean package`.
5. Faça o deploy de `target/crud-vendas.war` no servidor.
6. Acesse a aplicação pelo endereço fornecido pelo servidor.

## Capturas de tela

A pasta `screenshots/` contém uma composição visual ilustrativa das principais telas previstas no projeto: CRUD de Marca, cadastro/edição, hierarquia de Categorias, cadastro de Produto com imagem, filtros e paginação, mensagens de sucesso, confirmação de exclusão e visão do repositório GitHub.

> **Observação:** a imagem abaixo é **ilustrativa** e serve como apoio visual ao README. Para a entrega final, substitua-a por capturas reais da aplicação em execução, caso o professor exija evidência de funcionamento.

![Capturas ilustrativas do CRUD Vendas](screenshots/capturas-ilustrativas-crud-vendas.png)

## Git
Sugestão de histórico de commits:
```text
chore: cria estrutura Maven do projeto
feat: implementa entidades JPA de marca categoria e produto
feat: implementa camada DAO e persistencia
feat: implementa CRUD de marcas
feat: implementa CRUD de categorias hierarquicas
feat: implementa CRUD de produtos e upload de imagem
feat: adiciona interface PrimeFaces e validacoes
docs: adiciona README e scripts SQL
chore: configura gitignore
```

> Antes da entrega, substitua/adicione as capturas reais de funcionamento na pasta `screenshots/` e atualize esta seção com os nomes dos arquivos.
