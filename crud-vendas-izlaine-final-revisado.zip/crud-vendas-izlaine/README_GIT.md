# Checklist de entrega no GitHub

1. Crie um repositório público ou conforme orientação do professor.
2. Extraia este projeto.
3. Abra o terminal na pasta do projeto.
4. Execute:

```bash
git init
git branch -M main
git add .
git commit -m "chore: cria estrutura inicial do CRUD Vendas"
```

5. Faça commits adicionais conforme cada etapa implementada. O enunciado penaliza repositório com commit único.
6. Adicione o remoto fornecido pelo GitHub e envie:

```bash
git remote add origin URL_DO_SEU_REPOSITORIO
git push -u origin main
```

7. A pasta `screenshots/` já contém uma composição visual ilustrativa. Para a entrega, prefira substituir por prints reais da aplicação executando, se solicitado pelo professor.
