INSERT INTO tb_marca(nome,descricao,ativo) VALUES ('Nike','Marca de exemplo',true),('Adidas','Marca de exemplo',true) ON CONFLICT (nome) DO NOTHING;
INSERT INTO tb_categoria(nome,categoria_id) SELECT 'Calçados',NULL WHERE NOT EXISTS (SELECT 1 FROM tb_categoria WHERE nome='Calçados');
INSERT INTO tb_categoria(nome,categoria_id) SELECT 'Tênis',(SELECT id FROM tb_categoria WHERE nome='Calçados' LIMIT 1) WHERE NOT EXISTS (SELECT 1 FROM tb_categoria WHERE nome='Tênis');
