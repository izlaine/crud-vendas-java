CREATE DATABASE vendas;
-- Execute o restante conectado ao banco vendas.
CREATE TABLE IF NOT EXISTS tb_marca (id BIGSERIAL PRIMARY KEY, nome VARCHAR(100) NOT NULL UNIQUE, descricao VARCHAR(255), ativo BOOLEAN NOT NULL DEFAULT TRUE);
CREATE TABLE IF NOT EXISTS tb_categoria (id BIGSERIAL PRIMARY KEY, nome VARCHAR(120) NOT NULL, categoria_id BIGINT REFERENCES tb_categoria(id));
CREATE TABLE IF NOT EXISTS tb_produto (id BIGSERIAL PRIMARY KEY, nome VARCHAR(150) NOT NULL, descricao TEXT, preco NUMERIC(12,2) NOT NULL CHECK(preco>0), quantidade_estoque INTEGER NOT NULL CHECK(quantidade_estoque>=0), marca_id BIGINT NOT NULL REFERENCES tb_marca(id), categoria_id BIGINT NOT NULL REFERENCES tb_categoria(id), caminho_imagem VARCHAR(500));
