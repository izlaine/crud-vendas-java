package br.edu.vendas.dao;
import br.edu.vendas.util.JPAUtil; import jakarta.persistence.*; import java.util.*;
public abstract class GenericDAO<T> { private final Class<T> type; protected GenericDAO(Class<T> type){this.type=type;}
 public List<T> listar(){EntityManager em=JPAUtil.createEntityManager();try{return em.createQuery("from "+type.getSimpleName(),type).getResultList();}finally{em.close();}}
 public T buscar(Long id){EntityManager em=JPAUtil.createEntityManager();try{return em.find(type,id);}finally{em.close();}}
 public void salvar(T obj){tx(obj,false);} public void atualizar(T obj){tx(obj,true);} private void tx(T obj,boolean merge){EntityManager em=JPAUtil.createEntityManager();EntityTransaction tx=em.getTransaction();try{tx.begin();if(merge)em.merge(obj);else em.persist(obj);tx.commit();}catch(RuntimeException e){if(tx.isActive())tx.rollback();throw e;}finally{em.close();}}
 public void excluir(Long id){EntityManager em=JPAUtil.createEntityManager();EntityTransaction tx=em.getTransaction();try{tx.begin();T o=em.find(type,id);if(o!=null)em.remove(o);tx.commit();}catch(RuntimeException e){if(tx.isActive())tx.rollback();throw e;}finally{em.close();}}
}
