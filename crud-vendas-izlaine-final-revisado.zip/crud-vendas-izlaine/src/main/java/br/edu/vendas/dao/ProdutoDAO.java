package br.edu.vendas.dao; import br.edu.vendas.model.Produto; public class ProdutoDAO extends GenericDAO<Produto>{public ProdutoDAO(){super(Produto.class);}}
