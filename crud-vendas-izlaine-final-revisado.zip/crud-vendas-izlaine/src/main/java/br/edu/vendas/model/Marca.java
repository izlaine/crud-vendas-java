package br.edu.vendas.model;
import jakarta.persistence.*; import jakarta.validation.constraints.*; import java.io.Serializable;
@Entity @Table(name="tb_marca", uniqueConstraints=@UniqueConstraint(columnNames="nome"))
public class Marca implements Serializable {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @NotBlank @Size(max=100) @Column(nullable=false, unique=true) private String nome;
 @Size(max=255) private String descricao;
 @Column(nullable=false) private Boolean ativo=true;
 public Long getId(){return id;} public void setId(Long id){this.id=id;} public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;} public String getDescricao(){return descricao;} public void setDescricao(String descricao){this.descricao=descricao;} public Boolean getAtivo(){return ativo;} public void setAtivo(Boolean ativo){this.ativo=ativo;}
}
