package br.edu.vendas.model;
import jakarta.persistence.*; import jakarta.validation.constraints.*; import java.io.Serializable; import java.math.BigDecimal;
@Entity @Table(name="tb_produto")
public class Produto implements Serializable {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @NotBlank @Size(max=150) @Column(nullable=false) private String nome;
 @Lob private String descricao;
 @NotNull @DecimalMin(value="0.01") @Column(nullable=false, precision=12, scale=2) private BigDecimal preco;
 @NotNull @Min(0) @Column(nullable=false) private Integer quantidadeEstoque;
 @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="marca_id", nullable=false) private Marca marca;
 @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="categoria_id", nullable=false) private Categoria categoria;
 @Size(max=500) private String caminhoImagem;
 public Long getId(){return id;} public void setId(Long id){this.id=id;} public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;} public String getDescricao(){return descricao;} public void setDescricao(String descricao){this.descricao=descricao;} public BigDecimal getPreco(){return preco;} public void setPreco(BigDecimal preco){this.preco=preco;} public Integer getQuantidadeEstoque(){return quantidadeEstoque;} public void setQuantidadeEstoque(Integer quantidadeEstoque){this.quantidadeEstoque=quantidadeEstoque;} public Marca getMarca(){return marca;} public void setMarca(Marca marca){this.marca=marca;} public Categoria getCategoria(){return categoria;} public void setCategoria(Categoria categoria){this.categoria=categoria;} public String getCaminhoImagem(){return caminhoImagem;} public void setCaminhoImagem(String caminhoImagem){this.caminhoImagem=caminhoImagem;}
}
