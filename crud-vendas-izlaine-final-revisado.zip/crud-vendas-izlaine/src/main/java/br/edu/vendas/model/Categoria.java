package br.edu.vendas.model;
import jakarta.persistence.*; import jakarta.validation.constraints.*; import java.io.Serializable; import java.util.*;
@Entity @Table(name="tb_categoria")
public class Categoria implements Serializable {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @NotBlank @Size(max=120) @Column(nullable=false) private String nome;
 @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="categoria_id") private Categoria categoriaPai;
 @OneToMany(mappedBy="categoriaPai", cascade=CascadeType.ALL, orphanRemoval=false) private List<Categoria> subcategorias=new ArrayList<>();
 public Long getId(){return id;} public void setId(Long id){this.id=id;} public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;} public Categoria getCategoriaPai(){return categoriaPai;} public void setCategoriaPai(Categoria categoriaPai){this.categoriaPai=categoriaPai;} public List<Categoria> getSubcategorias(){return subcategorias;} public void setSubcategorias(List<Categoria> subcategorias){this.subcategorias=subcategorias;}
 public String getCaminho(){ return categoriaPai==null?nome:categoriaPai.getCaminho()+" / "+nome; }
 @Override public String toString(){return nome;}
}
