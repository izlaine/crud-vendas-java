package br.edu.vendas.util;
import jakarta.persistence.*;
public final class JPAUtil { private static final EntityManagerFactory emf=Persistence.createEntityManagerFactory("vendasPU"); private JPAUtil(){} public static EntityManager createEntityManager(){return emf.createEntityManager();} public static void close(){if(emf.isOpen()) emf.close();} }
